package com.example.clase1gtics;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase1gticsApplicationTests {

    @Test
    void contextLoads() {
    }

}
